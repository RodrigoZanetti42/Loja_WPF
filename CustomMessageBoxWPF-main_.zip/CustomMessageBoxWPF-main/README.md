# CustomMessageBoxWPF
WPF Material Design Custom Message Box

Types of custom message boxes

1. Ok and Cancel
2. Yes and No
3. Ok
   1. Ok with Information
   2. Ok with Warning
   3. Ok with Error
   4. Ok with Success
   
Ok and Cancel Message Box : 

   ![image](https://user-images.githubusercontent.com/34879901/156876517-968d40db-2ae6-4c6a-aa2c-ab05c66687c6.png)
   
Yes and No Message Box :

   ![image](https://user-images.githubusercontent.com/34879901/156876693-09b09c98-8e54-425b-96b7-f6e94e0ab6fc.png)

Types of Ok Message Boxes : 

![image](https://user-images.githubusercontent.com/34879901/156876832-3e12b152-44bf-4faa-bca3-1d2c56ee52b0.png)

![image](https://user-images.githubusercontent.com/34879901/156876965-b70108a8-dbd6-4502-851e-3d57027b72de.png)

![image](https://user-images.githubusercontent.com/34879901/156877032-402d3478-b4ac-4a0e-937c-1e800dbfcbca.png)

![image](https://user-images.githubusercontent.com/34879901/156877090-655e8f76-8606-4080-b8c6-7095d85669c3.png)

![image](https://user-images.githubusercontent.com/34879901/156877160-62efcecf-863a-41fb-b6ea-51a9e3c6b923.png)

